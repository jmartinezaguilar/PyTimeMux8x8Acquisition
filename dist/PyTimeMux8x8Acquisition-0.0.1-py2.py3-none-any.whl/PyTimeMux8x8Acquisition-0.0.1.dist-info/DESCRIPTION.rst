Tools for acquire continuously 8x8 matrix devices                 


